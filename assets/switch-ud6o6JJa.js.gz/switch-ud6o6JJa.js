import{_ as o}from"./switch.vue_vue_type_script_setup_true_lang-DPixL6L1.js";import"./bootstrap-DTzpk8a9.js";import"./index-Ce4LrBVu.js";export{o as default};

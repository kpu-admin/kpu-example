import{_ as o}from"./select.vue_vue_type_script_setup_true_lang-DBrmSYma.js";import"./bootstrap-DTzpk8a9.js";import"./index-Ce4LrBVu.js";export{o as default};

import{_ as o}from"./rate.vue_vue_type_script_setup_true_lang-BZ24Ckg_.js";import"./bootstrap-DTzpk8a9.js";import"./index-Ce4LrBVu.js";export{o as default};

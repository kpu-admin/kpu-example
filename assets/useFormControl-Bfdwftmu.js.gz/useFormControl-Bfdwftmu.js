import{c as r,aK as t,aL as a}from"./bootstrap-DTzpk8a9.js";function n(o){return r(()=>{var e;return t(o)?!!((e=a(o))!=null&&e.closest("form")):!0})}export{n as u};
